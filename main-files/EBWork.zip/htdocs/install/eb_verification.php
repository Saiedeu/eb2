<?php
// EB License System Verification File v2.0.0
// DO NOT MODIFY THIS FILE
return array (
  'license_key' => 'EB-L7US5-NBCS8-NR9X6-TT5N3',
  'domain' => 'demo.exchange-bridge.rf.gd',
  'status' => 'active',
  'hash' => 'cb49c43e818cacf74a2a3f031a99bb6c',
  'last_check' => 1762869009,
  'validation_type' => 'automatic',
  'expires' => 0,
  'server_status' => 'active',
  'created_at' => 1762869009,
  'version' => '2.0.0',
);
