<?php
// License verification data - DO NOT MODIFY
if (!defined('ALLOW_ACCESS')) { exit('Access Denied'); }
return array (
  'license_key' => 'EB-L7US5-NBCS8-NR9X6-TT5N3',
  'domain' => 'demo.exchange-bridge.rf.gd',
  'status' => 'active',
  'hash' => '2e7048b169e037ad8715029ff16fe9fd70f9d367719b5deb37a65c712d5e1987',
  'last_check' => 1762869086,
  'validation_type' => 'installation',
  'created_at' => 1762869086,
  'version' => '1.0.0',
);
